/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial321;

import java.util.ArrayList;
import parcial321.Nave;

/**
 *
 * @author Sebas
 */
public class Agencia {
    private String nombre;
    private ArrayList<Nave> naves;

    public Agencia(String nombre) {
        this.nombre = nombre;
        this.naves = new ArrayList<>();
    }

    public void agregarNave(Nave nave) {
    if (naves == null) {
        throw new NullPointerException("No se puede agregar una agencia nula.");
    }
    if (naves.contains(nave)) {
        throw new NaveYaExisteException();
    }
    naves.add(nave);
    }

    public void mostrarNaves(){
        for (Nave nave : naves) {
            System.out.println(nave);
        }
    }
    
    public void iniciarExploracion(){
        for (Nave nave : naves) {
            if (nave instanceof Exploradores exp) {
                exp.explorar();
                System.out.println("Es un " + nave.getNombre() + " puede explorar.");
            } else{
                System.out.println("Un " + nave.getNombre() + " NO puede explorar");
                }
            }
    }
}
