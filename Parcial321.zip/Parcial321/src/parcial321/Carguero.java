/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial321;

/**
 *
 * @author Sebas
 */
public class Carguero extends Nave implements Exploradores{
    private int capacidadCarga;
    private static final int CAPACIDAD_MINIMA = 100;
    private static final int CAPACIDAD_MAXIMA = 500;

    public Carguero(String nombre, int capacidadTripulacion, int anioLanzamiento, int capacidadCarga) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        validarCapacidadCarga(capacidadCarga);
        this.capacidadCarga = capacidadCarga;
    }
    
    private void validarCapacidadCarga(int capacidadCarga) {
        if (capacidadCarga < CAPACIDAD_MINIMA || capacidadCarga > CAPACIDAD_MAXIMA) {
            throw new IllegalArgumentException(
                "La capacidad de carga debe estar entre " + CAPACIDAD_MINIMA + " y " + CAPACIDAD_MAXIMA + " toneladas."
            );
        }
    }

    @Override
    public boolean explorar() {
        return true;
    }
    
    @Override
    public String toString() {
        return ("Carguero: " + getNombre() + ", Capacidad: " + getCapacidadTripulacion() +  ", Anio: " + getAnioLanzamiento() + ", Capacidad de carga : " + capacidadCarga);
    }
}
