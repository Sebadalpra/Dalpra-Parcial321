package parcial321;


public interface Exploradores {
    boolean explorar();
   
}
