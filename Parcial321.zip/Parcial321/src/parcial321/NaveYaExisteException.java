package parcial321;

public class NaveYaExisteException extends IllegalArgumentException {
    private final static String MENSAJE = "La nave que tratas de agregar ya existe.";
    
    public NaveYaExisteException() {
        super(MENSAJE);
    }
}
