
package parcial321;


public class Main {

    public static void main(String[] args) {
        
        try {
            Agencia agencia = new Agencia("Agencia Bs As");
            
            Nave exploracion1 = new NaveExploracion("Exlorador", 5, 2023, TipoMision.CARTOGRAFIA);
            Nave carguero1 = new Carguero("Galactica", 300, 2022, 300);
            Nave crucero1 = new CruceroEstelar("Crucero estelar", 50, 2021, 200);
            
            agencia.agregarNave(exploracion1);
            agencia.agregarNave(carguero1);
            agencia.agregarNave(crucero1);
            
            System.out.println("------------  1A. Verifiacion de nave Galactica repetida por nombre y anioLanzamiento: -----------");
            Nave carguero2 = new Carguero("Galactica", 500, 2022, 150);
            System.out.println("carguero1 y carguero2 son iguales?: " + carguero1.equals(carguero2));
            
            //System.out.println("------------  1B. Verifiacion de excepcion con carga fuera del rango (800): -----------");
            //agencia.agregarNave(new Carguero("Galactica", 500, 2022, 800));

            //System.out.println("------------ 1C. Agregando Nave repetida por nombre y anioLanzamiento para que lance la NaveYaExisteException: -----------");
            //agencia.agregarNave(carguero2);

            System.out.println("------------ 2. Mostrar las naves registradas: -----------");
            agencia.mostrarNaves();

            System.out.println("----------- 3. Iniciando exploracion: ------------");
            agencia.iniciarExploracion();
            
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
        
    }
    
