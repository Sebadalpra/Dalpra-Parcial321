/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial321;

/**
 *
 * @author Sebas
 */
public class NaveExploracion extends Nave implements Exploradores{
    private TipoMision tipoMision;
    
    public NaveExploracion(String nombre, int capacidadTripulacion, int anioLanzamiento, TipoMision tipoMision) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.tipoMision = tipoMision;
    }

    @Override
    public boolean explorar() {
        return true;
    }

    @Override
    public String toString() {
        return ("Nave de Exploracion: " + getNombre() + ", Capacidad: " + getCapacidadTripulacion() +  ", Anio: " + getAnioLanzamiento() + ", Mision: " + tipoMision);
    }
    
    
}
