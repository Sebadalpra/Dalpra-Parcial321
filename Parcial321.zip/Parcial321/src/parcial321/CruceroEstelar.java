/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial321;

/**
 *
 * @author Sebas
 */
public class CruceroEstelar extends Nave{
    private int cantPasajeros;

    public CruceroEstelar(String nombre, int capacidadTripulacion, int anioLanzamiento, int cantPasajeros) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.cantPasajeros = cantPasajeros;
    }

    @Override
    public String toString() {
        return ("Crucero estelar: " + getNombre() + ", Capacidad: " + getCapacidadTripulacion() +  ", Anio: " + getAnioLanzamiento() + ", Cantidad de pasajeros: " + cantPasajeros);
    }

    
    
}
