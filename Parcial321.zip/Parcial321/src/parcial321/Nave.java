/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial321;

import java.util.Objects;

/**
 *
 * @author Sebas
 */
public abstract class Nave {
    private String nombre;
    private int capacidadTripulacion;
    private int anioLanzamiento;

    public Nave(String nombre, int capacidadTripulacion, int anioLanzamiento) {
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.anioLanzamiento = anioLanzamiento;
    }

    public String getNombre() {
        return nombre;
    }

    protected int getCapacidadTripulacion() {
        return capacidadTripulacion;
    }

    protected int getAnioLanzamiento() {
        return anioLanzamiento;
    }


   
    @Override
    public abstract String toString();
    
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Nave other = (Nave) obj;
        return nombre.equals(other.nombre) && anioLanzamiento == other.anioLanzamiento;
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, anioLanzamiento);
    }
    
    
}
